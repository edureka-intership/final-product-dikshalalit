import React from 'react'
import Quicksearch from './Quicksearch'
import Wallpaper from './Wallpaper'

export default function Home() {
  return (
    <div>
        <Wallpaper/>
        <Quicksearch/>
    </div>
  )
}
