
import React from 'react'

export default function MealType(props) {
    return (
       

            <div className=" col-lg-4 col-md-6">
                <div className="card  mx-auto">
                    <div className="card-content">
                        <img src={require(`../`+props.item.image)} alt="breakfast" className="card-img"/>
                        <div className="ms-4">
                            <div className="cardhead">{props.item.name}</div>
                            <div className="cardtext">{props.item.content}</div>
                        </div>
                    </div>
                </div>
            </div>

       
    )
}

