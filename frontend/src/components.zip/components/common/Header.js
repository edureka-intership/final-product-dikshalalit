import React from 'react'
import './Header.css'

export default function Header() {
  return (
    <div>
        <div className="navbg">
        <div className="navcontainer container">

          <div className="navlogo">e!</div>

          <div className="navbtn">
            <button type="button" className="navloginbtn">Login</button>
            <button type="button" className="navaccountbtn">Create an account</button>
          </div>

        </div>
      </div>
    </div>
  )
}
