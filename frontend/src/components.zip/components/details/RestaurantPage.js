import React,{useState,useEffect} from 'react'
import Header from '../common/Header'
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import {useParams} from 'react-router-dom';

export default function RestaurantPage() {

const  [restaurant,setRestaurant]=useState({})
let {cName}=useParams()

useEffect(()=>{
    fetch(`http://localhost:9700/restaurant/name/${cName}`,{method:'GET'})
    .then(response=>response.json())
    .then(data=>setRestaurant(data.data))
},[])

const{name,locality,thumb,address,cost,Cuisine}=restaurant

const CuisineList=!(Cuisine==undefined) && Cuisine.length && <ul>{Cuisine.map(item=><li>{item.name}</li>)}</ul>


    return (
        <div>
            <Header />

            <div className="container mt-5">
                <img src={thumb} alt="wallpaper" className='deatil_img' />
                <div className="deatil_head mt-4">{name}</div>
            </div>

            <div className="container mt-5">
                <Tabs>
                    <TabList>
                        <Tab><h6 className="about_detail">Overview</h6></Tab>
                        <Tab><h6 className="about_detail">Contact</h6></Tab>
                    </TabList>

                    <TabPanel>
                        <h5 className="about_detail">About this place</h5>
                        <h6 className="haed_detail">Cuisine</h6>
                        {CuisineList}
                        <h6 className="haed_detail">Average cost</h6>
                        <p>{cost}</p>
                    </TabPanel>
                    <TabPanel>
                        <h5 className="about_detail">Get in Touch</h5>
                        <h6 className="haed_detail">Address</h6>
                        <p>{address}</p>
                        <h6 className="haed_detail">Average cost</h6>
                        <p>{locality}</p>
                    </TabPanel>
                </Tabs>
            </div>

        </div>
    )
}
